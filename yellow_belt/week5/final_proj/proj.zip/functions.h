#pragma once
#include<iostream>
#include<vector>


using namespace std;

template<class T>void VisitPlaces(const T& t, const vector<string> &places);